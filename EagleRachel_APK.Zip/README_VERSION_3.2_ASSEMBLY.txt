﻿================================================================================
THE FRATERNAL ORDER OF LADY EAGLES GROUP
Sargo Cambodia Lady Eagles Group - Application : Treasurer Financial Record
================================================================================
NOUVEAU PACK OFFICIEL ASSEMBLEE GENERALE EN 5 SLIDES DE PRESENTATION
VERSION 3.2 (Mise a jour du 29/10/2026 a 15h45)

Contenu du package ZIP :
1. EagleRachel_Full.apk   : Version ComplÃ¨te pour Smartphone & Tablette (v3.2)
2. EagleRachel_Light.apk  : Version AllÃ©gÃ©e Haute Performance (v3.2)
3. RachelEagles.apk       : Nom standard officiel
4. RachelEagles_Light.apk : Nom version mobile light
5. GUIDE_SYNCHRONISATION_ET_UTILISATION_FR.pdf (Guide utilisateur en FranÃ§ais)
6. SYNCHRONIZATION_AND_USER_GUIDE_EN.pdf (User Manual in English)
7. PROPOSITION_ACCES_MEMBRES_PRESIDENT.pdf (Proposition Gouvernance pour approbation)
8. PROPOSITION_ACCES_MEMBRES_PRESIDENT_EN.pdf (English Governance Proposal)

ARCHITECTURE EXACTE DES 5 SLIDES DE PRESENTATION (PDF OFFICIEL ASSEMBLEE) :
- SLIDE 1 : Page de garde d'attente (Occupe toute la hauteur de la feuille, AUCUN chiffre, 
            logos officiels, bienvenue aux membres et officiers, attente que l'assemblÃ©e soit au complet).
- SLIDE 2 : DÃ©penses par Famille (Histogramme HORIZONTAL reprenant les familles et montants 
            + Camembert de rÃ©partition en % avec code couleur. AUCUN tableau dessous).
- SLIDE 3 : Comparaison DÃ©bits / CrÃ©dits (Histogramme par semaine Recettes vs DÃ©penses 
            + Camembert exprimant la rÃ©partition en %. AUCUN tableau dessous).
- SLIDE 4 : Ã‰volution de la TrÃ©sorerie par Semaine et Mois (Histogramme flux net par semaine 
            + Camembert structure liquiditÃ©s + Courbe chronologique du solde cumulÃ©. AUCUN tableau dessous).
- SLIDE 5 : Bilan de SantÃ© BudgÃ©taire & Pistes d'AmÃ©lioration (RÃ©sumÃ© Ã©crit de la santÃ© financiÃ¨re, 
            4 pistes d'amÃ©lioration stratÃ©gique, rÃ©solution de quitus et double signature officielle 
            Rachel Chua - Group Treasurer & Sharon Llegado - Group President).
================================================================================