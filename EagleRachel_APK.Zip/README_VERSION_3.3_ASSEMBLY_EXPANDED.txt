﻿================================================================================
THE FRATERNAL ORDER OF LADY EAGLES GROUP
Sargo Cambodia Lady Eagles Group - Application : Treasurer Financial Record
================================================================================
PACK OFFICIEL ASSEMBLEE GENERALE EN 5 SLIDES DE PRESENTATION
VERSION 3.3 (Mise a jour du 29/10/2026 - LISIBILITE MAXIMALE PLEINE PAGE A4)

Contenu du package ZIP :
1. EagleRachel_Full.apk   : Version Complete pour Smartphone & Tablette (v3.3, versionCode 6)
2. EagleRachel_Light.apk  : Version AllÃ©gÃ©e Haute Performance (v3.3, versionCode 6)
3. RachelEagles.apk       : Nom standard officiel (v3.3)
4. RachelEagles_Light.apk : Nom version mobile light (v3.3)
5. GUIDE_SYNCHRONISATION_ET_UTILISATION_FR.pdf (Guide utilisateur en Francais)
6. SYNCHRONIZATION_AND_USER_GUIDE_EN.pdf (User Manual in English)
7. PROPOSITION_ACCES_MEMBRES_PRESIDENT.pdf (Proposition Gouvernance pour approbation)
8. PROPOSITION_ACCES_MEMBRES_PRESIDENT_EN.pdf (English Governance Proposal)

ARCHITECTURE EXACTE DES 5 SLIDES DE PRESENTATION (PDF OFFICIEL ASSEMBLEE) :
- SLIDE 1 : Page de garde d'attente (Occupe 100% de la hauteur de la feuille A4, AUCUN chiffre, 
            trio de logos officiels Ã©largis, bienvenue officielle aux membres et officiers, 
            attente que l'assemblÃ©e soit au complet, signataires Rachel Chua et Sharon Llegado).
- SLIDE 2 : DÃ©penses par Famille (Histogramme HORIZONTAL Ã©largi 380px reprenant les familles et montants 
            + Camembert de rÃ©partition en % avec code couleur et lÃ©gende en bas. 3 KPI . AUCUN tableau dessous).
- SLIDE 3 : Comparaison DÃ©bits / CrÃ©dits (Histogramme hebdomadaire Ã©largi 380px Recettes vs DÃ©penses 
            + Camembert de rÃ©partition en %. 3 KPI . Analyse d'Ã©quilibre financier. AUCUN tableau dessous).
- SLIDE 4 : Ã‰volution de la TrÃ©sorerie par Semaine et Mois (Histogramme flux net par semaine 
            + Camembert structure liquiditÃ©s + Grande courbe chronologique du solde cumulÃ© sur toute la largeur. AUCUN tableau dessous).
- SLIDE 5 : Bilan de SantÃ© BudgÃ©taire & Pistes d'AmÃ©lioration (Diagnostic financier Ã©crit, 
            4 pistes d'amÃ©lioration stratÃ©gique 2x2, rÃ©solution de quitus solennelle et signatures officielles 
            Rachel Chua - Group Treasurer & Sharon Llegado - Group President).
================================================================================